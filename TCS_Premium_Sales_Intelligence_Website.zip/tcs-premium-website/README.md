# TCS Sales Intelligence — Premium Website

A responsive React + Vite website that uses the uploaded Excel workbook's **Cleaned Data** sheet to power an interactive sales dashboard.

## What's included
- Animated corporate hero, loader, section reveals, hover effects, responsive navigation
- Metrics calculated from the included dataset
- Monthly sales trend, category sales, order status chart
- Filters for product category and order status
- Regional, city, and payment-method summaries
- Contact form with client-side validation and status feedback
- Reduced-motion support, semantic sections, responsive mobile layout
- `public/sales-data.json`: dataset exported from the provided workbook

## Important data note
The provided workbook contains e-commerce order data (800 records), not employee records. This website therefore presents the dataset as a sales intelligence dashboard. “TCS” is used as the requested editable brand label and does not imply these figures are official TCS company financial results. Replace the logo/brand copy and content as needed before publishing.

The cleaned workbook's sales formula cells do not have cached values when read programmatically, so the export recomputes `Gross_Sales`, `Discount_Amount`, and `Net_Sales` from `Quantity`, `Unit_Price`, and `Discount_Percent`. The discount field is treated as a decimal when <= 1 and as a percentage when > 1.

## Requirements
- Node.js 18+ recommended
- npm

## Run locally
1. Extract the ZIP folder.
2. Install Node.js from https://nodejs.org if you do not already have it.
3. Open a terminal in this project folder (the folder containing `package.json`).
4. Run:

   ```bash
   npm install
   npm run dev
   ```

5. Open the local URL Vite prints, usually `http://localhost:5173`.

## Production build
Run:

```bash
npm run build
npm run preview
```

The deployable static site is generated in `dist/`. Upload the contents of `dist/` to a static hosting provider or connect the project to your preferred deployment workflow.

## Customizing the data
- Replace `public/sales-data.json` with a JSON array of records using the same field names, or export a new version from Excel.
- Expected fields include `Order_ID`, `Order_Date`, `Month`, `Product_Category`, `Quantity`, `Unit_Price`, `Discount_Percent`, `Net_Sales`, `Order_Status`, `Region`, `City`, and `Payment_Method`.
- The dashboard calculations happen in `src/main.jsx` in the `analytics` `useMemo` block.

## Contact form
The form currently validates input in the browser and shows success/error feedback. **It does not send email or store messages.** Before publishing, connect `submitForm` in `src/main.jsx` to a backend endpoint or a form service. Never put private API keys in client-side code.

## Branding and company information
The TCS wordmark is a custom CSS-built placeholder logo, not an official supplied logo file. Replace it with your approved logo if you have one. Company contact details, social accounts, team members, and client logos are intentionally not invented.

## Troubleshooting
- If `npm` is not recognized, install Node.js and restart the terminal.
- If install errors persist, check that your Node.js version is 18+ and rerun `npm install`.
- If a port is busy, Vite will print another local URL.
- This project uses Vite's development server; do not open `index.html` directly from the file manager.
